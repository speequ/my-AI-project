@echo off
cd /d "C:\path\to\your\mybot\folder"
python mybot.py
pause
